from flask import Flask, render_template, request

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def calculate_attendance():
    result = None
    if request.method == "POST":
        try:
            total_classes = int(request.form.get("total_classes"))
            attended_classes = int(request.form.get("attended_classes"))
            if total_classes > 0 and attended_classes <= total_classes:
                percentage = (attended_classes / total_classes) * 100
                result = f"Your attendance percentage is: {percentage:.2f}%"
            else:
                result = "Invalid input. Total classes must be greater than zero, and attended classes cannot exceed total classes."
        except ValueError:
            result = "Please enter valid numeric values."
    return render_template("index.html", result=result)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5001)
