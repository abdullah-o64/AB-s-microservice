from flask import Flask, render_template, request

app = Flask(__name__)

# Conversion logic
def convert_units(value, from_unit, to_unit, conversion_type):
    try:
        value = float(value)
        if conversion_type == "length":
            conversions = {
                "meters": 1,
                "kilometers": 0.001,
                "miles": 0.000621371,
                "feet": 3.28084
            }
        elif conversion_type == "weight":
            conversions = {
                "grams": 1,
                "kilograms": 0.001,
                "pounds": 0.00220462,
                "ounces": 0.035274
            }
        elif conversion_type == "temperature":
            if from_unit == "celsius" and to_unit == "fahrenheit":
                return value * 9/5 + 32
            elif from_unit == "fahrenheit" and to_unit == "celsius":
                return (value - 32) * 5/9
            elif from_unit == "celsius" and to_unit == "kelvin":
                return value + 273.15
            elif from_unit == "kelvin" and to_unit == "celsius":
                return value - 273.15
            else:
                return value
        else:
            return "Invalid Conversion Type"

        return value * conversions[to_unit] / conversions[from_unit]
    except Exception as e:
        return f"Error: {e}"

@app.route("/", methods=["GET", "POST"])
def home():
    result = None
    if request.method == "POST":
        value = request.form.get("value")
        from_unit = request.form.get("from_unit")
        to_unit = request.form.get("to_unit")
        conversion_type = request.form.get("conversion_type")
        result = convert_units(value, from_unit, to_unit, conversion_type)
    return render_template("index.html", result=result)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5003)
