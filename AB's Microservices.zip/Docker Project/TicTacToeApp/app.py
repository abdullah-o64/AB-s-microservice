from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# Initialize the board
board = [""] * 9
current_player = "X"


@app.route("/", methods=["GET", "POST"])
def index():
    global board, current_player

    # Handle a move
    if request.method == "POST":
        cell = int(request.form.get("cell"))
        if board[cell] == "":
            board[cell] = current_player
            if check_winner():
                winner = f"Player {current_player} wins!"
                return render_template("index.html", board=board, winner=winner)
            elif "" not in board:
                winner = "It's a tie!"
                return render_template("index.html", board=board, winner=winner)
            current_player = "O" if current_player == "X" else "X"

    return render_template("index.html", board=board, winner=None)


@app.route("/reset")
def reset():
    global board, current_player
    board = [""] * 9
    current_player = "X"
    return redirect(url_for("index"))


def check_winner():
    # Winning combinations
    win_combinations = [
        [0, 1, 2], [3, 4, 5], [6, 7, 8],  # Rows
        [0, 3, 6], [1, 4, 7], [2, 5, 8],  # Columns
        [0, 4, 8], [2, 4, 6],            # Diagonals
    ]
    for combo in win_combinations:
        if board[combo[0]] == board[combo[1]] == board[combo[2]] != "":
            return True
    return False


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5002)
